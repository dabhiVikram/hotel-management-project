package jdbc;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.sql.*;
public class Update extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try{
            HttpSession session=request.getSession(false);
            if(session.getAttribute("name")!=null)
            {
                Connection cn=ConnDB.conn();
                Statement st=cn.createStatement();
                ResultSet rs=st.executeQuery("select * from product where id="+Integer.parseInt(request.getParameter("pid")));
                rs.next();
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet Update</title>");            
                out.println("</head>");
                out.println("<body>");
                out.println("<h1></h1>");
                 out.println("<form><table>"
                    + "<tr>"
                    + "<td>Product Name : </td>"
                    + "<td><input type='text' name='txtnm' value='"+rs.getString(2)+"' /></td>"
                    + "</tr>"
                    + "<tr>"
                    + "<td>Product Price : </td>"
                    + "<td><input type='text' name='txtprice' value='"+rs.getDouble(3)+"' /></td>"
                    + "</tr>"
                    + "<tr>"
                    + "<td><input type='hidden' name='pid' value='"+rs.getInt(1)+"' /></td>"
                    + "</tr><tr>"
                    + "<td><input type='submit' name='updateproduct' value='Update' /></td>"
                    + "<td><input type='reset' name='reset' value='Cancle' /></td>"
                    + "</tr>"
                    + "</table></form>");
                out.println("</body>");
                out.println("</html>");
                rs.close();
                st.close();
                if(request.getParameter("updateproduct")!=null)
                {
                    PreparedStatement pst=cn.prepareStatement("update product set name=?,price=? where id=?");
                    pst.setString(1, request.getParameter("txtnm"));
                    pst.setDouble(2, Double.parseDouble(request.getParameter("txtprice")));
                    pst.setInt(3, Integer.parseInt(request.getParameter("pid")));
                    pst.execute();
                    pst.close();
                    cn.close();
                    response.sendRedirect("SelectAll");
                }
            }
        }
        catch(Exception e){out.println(e);}
    }
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req,resp);
    }
  /* @Override
  protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req,resp);
    }*/
}
