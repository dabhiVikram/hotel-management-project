package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import java.io.*;
public class LoginServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try{
            String name=request.getParameter("name");
            String password=request.getParameter("password");
            request.getRequestDispatcher("menu.html").include(request, response);
            if(password.equals("123"))
            {
                out.println("Welcome , " + name);
                HttpSession session=request.getSession();
                session.setAttribute("name", name);
            }
            else
            {
                out.println("Sorry , username or password error!");
                response.sendRedirect("index.html");
            }
        }
        catch(Exception e){
            out.println(e);
        }
    }

 /*   @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req,resp);
    }*/
    

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req,resp);
    }
    
}
