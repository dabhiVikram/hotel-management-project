package jdbc;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;
import java.io.*;
import java.sql.*;

public class SelectAll extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try{
            HttpSession session=request.getSession(false);
            if(session.getAttribute("name")!=null)
            {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet SelectAll</title>");            
                out.println("</head>");
                out.println("<body><center>");
                request.getRequestDispatcher("menu.html").include(request, response);
                out.println("<h1>Veiw All Product</h1>");
                out.println("<table calpadding'5' cellpacing'5' border='1'");
                
                Connection cn=ConnDB.conn();
                Statement st=cn.createStatement();
                ResultSet rs=st.executeQuery("select * from product");
                ResultSetMetaData rsmd=rs.getMetaData();
                if(rs.first())
                {
                    int no=rsmd.getColumnCount();
                    out.println("<tr>");
                    for(int i=1;i<=no;i++)
                        out.println("<th>"+rsmd.getColumnName(i)+"</th>");
                    out.println("<th colspan='2'>Task</th></tr>");
                    do{
                        out.println("<tr>"
                                + "<td>"+rs.getInt(1)+"</td>"
                                + "<td>"+rs.getString(2)+"</td>"
                                + "<td>"+rs.getDouble(3)+"</td>"
                                + "<td><a href='Update?pid="+rs.getInt(1)+"' />Edit</td>"
                                + "<td><a href='Delete?pid="+rs.getInt(1)+"' />Delete</td>");
                    }while(rs.next());
                }
                else{
                    out.println("No records found");
                }
                out.println("</center></body>");
                out.println("</html>");
            }
        }
        catch(Exception e){out.println(e);}
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req,resp);
    }
    

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req,resp);
        
    }
    
}
