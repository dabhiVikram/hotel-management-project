package jdbc;
import java.io.IOException;
import java.io.PrintWriter;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.RequestDispatcher;
import java.io.*;
import java.sql.Connection;
import javax.servlet.http.HttpSession;
import java.sql.PreparedStatement;

public class Insert extends HttpServlet {
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        PrintWriter out = response.getWriter();
        try{
            HttpSession session=request.getSession(false);
            if(session.getAttribute("name")!=null)
            {
                out.println("<!DOCTYPE html>");
                out.println("<html>");
                out.println("<head>");
                out.println("<title>Servlet Insert</title>");
                out.println("</head>");
                out.println("<body>");
                out.println("<h3>Welcome,"+session.getAttribute("name")+"</h3><br />");
                request.getRequestDispatcher("menu.html").include(request, response);
                out.println("<h1>Insert New Product</h1>");
                out.println("<form><table>"
                    + "<tr>"
                    + "<td>Product Name : </td>"
                    + "<td><input type='text' name='txtnm'></td>"
                    + "</tr>"
                    + "<tr>"
                    + "<td>Product Price : </td>"
                    + "<td><input type='text' name='txtprice'></td>"
                    + "</tr>"
                    + "<tr>"
                    + "<td><input type='submit' name='insproduct' value='Add new'></td>"
                    + "<td><input type='reset' name='reset' value='Cancle'></td>"
                    + "</tr>"
                    + "</table></form>");
                out.println("</body>");
                out.println("</html>");
                if(request.getParameter("insproduct")!=null)
                {
                    Connection cn=ConnDB.conn();
                    PreparedStatement pst=cn.prepareStatement("insert into product values(null,?,?)");
                    pst.setString(1, request.getParameter("txtnm"));
                    pst.setDouble(2, Double.parseDouble(request.getParameter("txtprice")));
                    pst.execute();
                    pst.close();
                    cn.close();
                    response.sendRedirect("SelectAll");
                }
            }
            else
            {
                response.sendRedirect("index.html");
            }
        }
        catch(Exception e){out.println(e);}
    }
  @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req,resp);
    }
    /*@Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        processRequest(req,resp);
    }*/
}
